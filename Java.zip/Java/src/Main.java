public class Main {
    public static void main(String[] args) {
        int resultado;
        resultado=suma(10,10,10);
        System.out.println("La suma es: " +resultado);
        Coche miCoche= new Coche();
        miCoche.sumarpuertas();
        System.out.println("El numero de puertas es: "+miCoche.puertas);
    }
    public static int suma(int a, int b, int c){
        return a+ b+ c;
    }
}
 class Coche {
    public int puertas=0;

    public void sumarpuertas(){
        this.puertas++;
    }

}